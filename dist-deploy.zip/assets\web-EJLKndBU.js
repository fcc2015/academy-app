import{W as n}from"./index-ClYwvoaq.js";import"./react-vendor-5nSCC_1E.js";import"./ui-vendor-DxVRTllW.js";class t extends n{async show(e){}async hide(e){}}export{t as SplashScreenWeb};
